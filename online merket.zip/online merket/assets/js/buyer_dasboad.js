let order= document.querySelector(".order");
let completed_order= document.querySelector(".completed_order");
let notification= document.querySelector(".notification");
let more= document.querySelector(".more");
let dasboad_section_all_box= document.querySelector(".dasboad_section_all_box");

document.querySelector(".order_itm").addEventListener("click", show_order_box);

function show_order_box(){
    order.style.display = "block";
    completed_order.style.display = "none";
    notification.style.display = "none";
    more.style.display = "none";
    dasboad_section_all_box.style.display = "none";
}

document.querySelector(".com_order_itm").addEventListener("click", show_com_order_box);

function show_com_order_box(){
    order.style.display = "none";
    completed_order.style.display = "block";
    notification.style.display = "none";
    more.style.display = "none";
    dasboad_section_all_box.style.display = "none";
}

document.querySelector(".notifition_itm").addEventListener("click", notifition_box);

function notifition_box(){
    order.style.display = "none";
    completed_order.style.display = "none";
    notification.style.display = "block";
    more.style.display = "none";
    dasboad_section_all_box.style.display = "none";
}

document.querySelector(".more_itm").addEventListener("click", more_box);

function more_box(){
    order.style.display = "none";
    completed_order.style.display = "none";
    notification.style.display = "none";
    more.style.display = "block";
    dasboad_section_all_box.style.display = "none";
}