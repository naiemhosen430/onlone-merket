
let Product_home_box= document.querySelector(".Product_home_box");
let contract_box= document.querySelector(".contract_box");
let about_as_box= document.querySelector(".about_as_box");


document.querySelector(".Product_home").addEventListener("click", show_Product_home);

function show_Product_home(){
    Product_home_box.style.display = "block";
    contract_box.style.display = "none";
    about_as_box.style.display = "none";
}

document.querySelector(".contract").addEventListener("click", show_contract);

function show_contract(){
    Product_home_box.style.display = "none";
    contract_box.style.display = "block";
    about_as_box.style.display = "none";
}

document.querySelector(".about_as").addEventListener("click", show_about_as);

function show_about_as(){
    Product_home_box.style.display = "none";
    contract_box.style.display = "none";
    about_as_box.style.display = "block";
}