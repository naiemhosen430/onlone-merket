
let product_sec= document.querySelector(".product_section");
let shop_sec= document.querySelector(".shop_section");

document.querySelector(".product_button").addEventListener("click", show_product);

function show_product(){
    product_sec.style.display = "block";
    shop_sec.style.display = "none";
}

document.querySelector(".shop_button").addEventListener("click", show_shop);

function show_shop(){
    shop_sec.style.display = "block";
    product_sec.style.display = "none";
}








